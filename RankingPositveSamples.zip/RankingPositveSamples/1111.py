train = []
test = []

# # 将购买行为训练集变成只有两列的形式
with open('tmall/pv.txt') as f:
    for line in f:
        line = line.strip().split(' ')
        user_id = line[0]
        items = line[1:]
        for item in items:
            train.append(user_id + ' ' + item + '\n')

with open('tmall/view.txt', 'w') as f:
    f.writelines(train)

train = []
with open('tmall/fav.txt') as f:
    for line in f:
        line = line.strip().split(' ')
        user_id = line[0]
        items = line[1:]
        for item in items:
            train.append(user_id + ' ' + item + '\n')

with open('tmall/collect.txt', 'w') as f:
    f.writelines(train)

train = []
with open('tmall/cart.txt') as f:
    for line in f:
        line = line.strip().split(' ')
        user_id = line[0]
        items = line[1:]
        for item in items:
            train.append(user_id + ' ' + item + '\n')

with open('tmall/cart.txt', 'w') as f:
    f.writelines(train)

train = []
with open('tmall/train.txt') as f:
    for line in f:
        line = line.strip().split(' ')
        user_id = line[0]
        items = line[1:]
        for item in items:
            train.append(user_id + ' ' + item + '\n')

with open('tmall/train.txt', 'w') as f:
    f.writelines(train)

# # 将购买行为测试集变成只有两列的形式
with open('tmall/test.txt') as f:
    for line in f:
        line = line.strip().split(' ')
        user_id = line[0]
        item = line[1:][0]
        test.append(user_id + ' ' + item[:] + '\n')
with open('tmall/test.txt', 'w') as f:
    f.writelines(test)

# with open('buy_test.txt', 'w') as f:
#     f.writelines(test)

# 将所有行为作为训练集
# with open('pv.txt') as f:
#     for line in f:
#         line = line.strip().split(' ')
#         user_id = line[0]
#         items = line[1:]
#         for item in items:
#             train.append(user_id + ' ' + item + ' 1\n')
#
# with open('cart.txt') as f:
#     for line in f:
#         line = line.strip().split(' ')
#         user_id = line[0]
#         items = line[1:]
#         for item in items:
#             train.append(user_id + ' ' + item + ' 1\n')
#
# with open('train.txt') as f:
#     for line in f:
#         line = line.strip().split(' ')
#         user_id = line[0]
#         items = line[1:]
#         for item in items:
#             train.append(user_id + ' ' + item + ' 1\n')

# with open('trainTemp1.txt', 'w') as f:
#     f.writelines(train)

# with open('train_all.txt') as f:
#     for line in f:
#         line = line.strip().split(' ')
#         user_id = line[0]
#         items = line[1:]
#         for item in items:
#             train.append(user_id + ' ' + item + ' 1\n')
#
# with open('train_all_process.txt', 'w') as f:
#     f.writelines(train)