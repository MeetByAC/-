import numpy as np
from collections import defaultdict
from data.data import Data
from data.graph import Graph
import scipy.sparse as sp
import pickle

from sklearn.metrics.pairwise import cosine_similarity
from itertools import combinations
from scipy.spatial.distance import pdist, squareform
from time import time
import os

class Interaction(Data,Graph):
    def __init__(self, conf, training, test):
        Graph.__init__(self)
        Data.__init__(self,conf,training,test)

        self.user = {}
        self.item = {}
        self.id2user = {}
        self.id2item = {}
        self.training_set_u = defaultdict(dict)
        self.training_set_i = defaultdict(dict)

        self.test_set = defaultdict(dict)
        self.test_set_item = set()
        self.__generate_set()

        self.user_num = len(self.training_set_u)
        self.item_num = len(self.training_set_i)

        self.ui_adj = self.__create_sparse_bipartite_adjacency()
        self.norm_adj = self.normalize_graph_mat(self.ui_adj)

        self.interaction_mat = self.__create_sparse_interaction_matrix()
        # popularity_user = {}
        # for u in self.user:
        #     popularity_user[self.user[u]] = len(self.training_set_u[u])
        # popularity_item = {}
        # for u in self.item:
        #     popularity_item[self.item[u]] = len(self.training_set_i[u])

        self.user_sim_mat, self.item_sim_mat = self.__create_similarity_adjacency_matrix()

    def __generate_set(self):
        for user, item, rating in self.training_data:
            if user not in self.user:
                user_id = len(self.user)
                self.user[user] = user_id
                self.id2user[user_id] = user
            if item not in self.item:
                item_id = len(self.item)
                self.item[item] = item_id
                self.id2item[item_id] = item
            self.training_set_u[user][item] = rating
            self.training_set_i[item][user] = rating

        for entry in self.test_data:
            user, item, rating = entry
            if user not in self.user or item not in self.item:
                continue
            self.test_set[user][item] = rating
            self.test_set_item.add(item)

    def __create_sparse_bipartite_adjacency(self, self_connection=False):
        n_nodes = self.user_num + self.item_num
        user_np = np.array([self.user[pair[0]] for pair in self.training_data])
        item_np = np.array([self.item[pair[1]] for pair in self.training_data]) + self.user_num
        ratings = np.ones_like(user_np, dtype=np.float32)
        tmp_adj = sp.csr_matrix((ratings, (user_np, item_np)), shape=(n_nodes, n_nodes), dtype=np.float32)
        adj_mat = tmp_adj + tmp_adj.T
        if self_connection:
            adj_mat += sp.eye(n_nodes)
        return adj_mat

    def convert_to_laplacian_mat(self, adj_mat):
        adj_shape = adj_mat.get_shape()
        n_nodes = adj_shape[0]+adj_shape[1]
        (user_np_keep, item_np_keep) = adj_mat.nonzero()
        ratings_keep = adj_mat.data
        tmp_adj = sp.csr_matrix((ratings_keep, (user_np_keep, item_np_keep + adj_shape[0])),shape=(n_nodes, n_nodes),dtype=np.float32)
        tmp_adj = tmp_adj + tmp_adj.T
        return self.normalize_graph_mat(tmp_adj)

    def __create_sparse_interaction_matrix(self):
        """
        return a sparse adjacency matrix with the shape (user number, item number)
        """
        row, col, entries = [], [], []
        for pair in self.training_data:
            row += [self.user[pair[0]]]
            col += [self.item[pair[1]]]
            entries += [1.0]
        interaction_mat = sp.csr_matrix((entries, (row, col)), shape=(self.user_num,self.item_num),dtype=np.float32)

        return interaction_mat

    def get_user_id(self, u):
        if u in self.user:
            return self.user[u]

    def get_item_id(self, i):
        if i in self.item:
            return self.item[i]

    def training_size(self):
        return len(self.user), len(self.item), len(self.training_data)

    def test_size(self):
        return len(self.test_set), len(self.test_set_item), len(self.test_data)

    def contain(self, u, i):
        'whether user u rated item i'
        if u in self.user and i in self.training_set_u[u]:
            return True
        else:
            return False

    def contain_user(self, u):
        'whether user is in training set'
        if u in self.user:
            return True
        else:
            return False

    def contain_item(self, i):
        """whether item is in training set"""
        if i in self.item:
            return True
        else:
            return False

    def user_rated(self, u):
        return list(self.training_set_u[u].keys()), list(self.training_set_u[u].values())

    def item_rated(self, i):
        return list(self.training_set_i[i].keys()), list(self.training_set_i[i].values())

    def row(self, u):
        u = self.id2user[u]
        k, v = self.user_rated(u)
        vec = np.zeros(len(self.item))
        # print vec
        for pair in zip(k, v):
            iid = self.item[pair[0]]
            vec[iid] = pair[1]
        return vec

    def col(self, i):
        i = self.id2item[i]
        k, v = self.item_rated(i)
        vec = np.zeros(len(self.user))
        # print vec
        for pair in zip(k, v):
            uid = self.user[pair[0]]
            vec[uid] = pair[1]
        return vec

    def matrix(self):
        m = np.zeros((len(self.user), len(self.item)))
        for u in self.user:
            k, v = self.user_rated(u)
            vec = np.zeros(len(self.item))
            # print vec
            for pair in zip(k, v):
                iid = self.item[pair[0]]
                vec[iid] = pair[1]
            m[self.user[u]] = vec
        return m

    def __create_similarity_adjacency_matrix(self):
        user_similarity = cosine_similarity(self.interaction_mat)
        item_similarity = cosine_similarity(self.interaction_mat.transpose())

        return user_similarity, item_similarity

    def __create_Jaccard_sim_adjacency_matrix(self, index):
        user_matrix = self.interaction_mat.toarray()
        item_matrix = user_matrix.T
        user_matrix, item_matrix = np.array(user_matrix, dtype=int),np.array(item_matrix, dtype=int)

        # 计算交集和并集
        # user_intersection = np.dot(user_matrix, user_matrix.T)
        # user_union = np.sum(np.logical_or(user_matrix[:, None, :], user_matrix[None, :, :]), axis=2)

        # 计算杰卡德相似度
        # user_jaccard_sim_matrix = user_intersection / user_union
        user_pairwise_distances = pdist(user_matrix, metric='jaccard')
        user_jaccard_sim_matrix = 1 - squareform(user_pairwise_distances)# 使用pdist计算杰卡德相似度
        item_pairwise_distance = pdist(item_matrix, metric='jaccard')
        item_jaccard_sim_matrix = 1 - squareform(item_pairwise_distance)
        np.savez(self.config.config['training.set'][:index] + '/user_jaccard_sim.npz', data=user_jaccard_sim_matrix)
        np.savez(self.config.config['training.set'][:index] + '/item_jaccard_sim.npz', data=item_jaccard_sim_matrix)


    def __create_item_swing_sim_adjacency_matrix(self):
        alpha = 1
        item_pairs = list(combinations(self.training_set_i.keys(), 2))  # 全排列组合对
        item_swing_sim_mat = np.zeros((self.item_num, self.item_num))
        user_matrix = np.zeros((self.user_num, self.user_num))
        print("item pairs length：{}".format(len(item_pairs)))
        for (i, j) in item_pairs:  # 这一步需要计算所有的item_i和item_j的相似度，非常耗时，速度慢
            # item_i和item_j对应的user取交集后组合 得到user对
            user_pairs = list(combinations(self.training_set_i[i].keys() & self.training_set_i[j].keys(), 2))
            result = 0
            for (u, v) in user_pairs:
                intersection = user_matrix[self.user[u]][self.user[v]]
                if intersection == 0:
                    user_matrix[self.user[u]][self.user[v]] = len(self.training_set_u[u].keys() & self.training_set_u[v].keys())
                    intersection = user_matrix[self.user[u]][self.user[v]]
                result += 1 / (alpha + intersection)  # 分数公式
            if result != 0:
                item_swing_sim_mat[self.item[i]][self.item[j]] = result
        return item_swing_sim_mat
        # item_sim_dict.setdefault(i, dict())
        # item_sim_dict[i][j] = result
        # return item_sim_dict


    def __create_user_swing_sim_adjacency_matrix(self):
        alpha = 1
        user_pairs = list(combinations(self.training_set_u.keys(), 2))  # 全排列组合对
        user_swing_sim_mat = np.zeros((self.user_num, self.user_num))
        item_matrix = np.zeros((self.item_num, self.item_num))
        print("user pairs length：{}".format(len(user_pairs)))
        for (u, v) in user_pairs:
            item_pairs = list(combinations(self.training_set_u[u].keys() & self.training_set_u[v].keys(), 2))
            result = 0
            for (i, j) in item_pairs:
                intersection = item_matrix[self.item[i]][self.item[j]]
                if intersection == 0:
                    item_matrix[self.item[i]][self.item[j]] = len(self.training_set_i[i].keys() & self.training_set_i[j].keys())
                    intersection = item_matrix[self.user[u]][self.user[v]]
                result += 1 / (alpha + intersection)  # 分数公式
            if result != 0:
                user_swing_sim_mat[self.user[u]][self.user[v]] = result
        return user_swing_sim_mat