import torch
import torch.nn.functional as F
import torch.nn as nn
import numpy as np


def bpr_loss(user_emb, pos_item_emb, neg_item_emb):
    pos_score = torch.mul(user_emb, pos_item_emb).sum(dim=1)
    neg_score = torch.mul(user_emb, neg_item_emb).sum(dim=1)
    loss = -torch.log(10e-6 + torch.sigmoid(pos_score - neg_score))
    return torch.mean(loss)

def triplet_loss(user_emb, pos_item_emb, neg_item_emb):
    pos_score = torch.mul(user_emb, pos_item_emb).sum(dim=1)
    neg_score = torch.mul(user_emb, neg_item_emb).sum(dim=1)
    loss = F.relu(neg_score+1-pos_score)
    return torch.mean(loss)

def l2_reg_loss(reg, *args):
    emb_loss = 0
    for emb in args:
        emb_loss += torch.norm(emb, p=2)/emb.shape[0]
    return emb_loss * reg


def batch_softmax_loss(user_emb, item_emb, temperature):
    user_emb, item_emb = F.normalize(user_emb, dim=1), F.normalize(item_emb, dim=1)
    pos_score = (user_emb * item_emb).sum(dim=-1)
    pos_score = torch.exp(pos_score / temperature)
    ttl_score = torch.matmul(user_emb, item_emb.transpose(0, 1))
    ttl_score = torch.exp(ttl_score / temperature).sum(dim=1)
    loss = -torch.log(pos_score / ttl_score+10e-6)
    return torch.mean(loss)


def InfoNCE(view1, view2, temperature, b_cos = True):
    if b_cos:
        view1, view2 = F.normalize(view1, dim=1), F.normalize(view2, dim=1)
    pos_score = (view1 * view2).sum(dim=-1)
    pos_score = torch.exp(pos_score / temperature)
    ttl_score = torch.matmul(view1, view2.transpose(0, 1))
    ttl_score = torch.exp(ttl_score / temperature).sum(dim=1)
    cl_loss = -torch.log(pos_score / ttl_score+10e-6)
    return torch.mean(cl_loss)

def instance_weighting_InfoNCE(view1, view2, origin_view, emb_eta, temperature, b_cos = True):
    if b_cos:
        view1, view2, origin_view = F.normalize(view1, dim=1), F.normalize(view2, dim=1), F.normalize(origin_view, dim=1)
    pos_score = (view1 * view2).sum(dim=-1)
    pos_score = torch.exp(pos_score / temperature)
    ttl_score = torch.matmul(view1, view2.transpose(0, 1))
    mask_matrix = ~(torch.matmul(view1, view2.transpose(0, 1)) >= emb_eta)
    ttl_score = (torch.exp(ttl_score / temperature) * mask_matrix).sum(dim=1)
    cl_loss = -torch.log(pos_score / ttl_score + 10e-6)
    return torch.mean(cl_loss)

def supervised_InfoNCE(view1, view2, similarity_matrix, idx, N, temperature, b_cos=True):
    idx = idx.cpu().numpy()
    similarity_idx = similarity_matrix[idx, :][:, idx]
    if b_cos:
        view1, view2 = F.normalize(view1, dim=1), F.normalize(view2, dim=1)
    neg_matrix = torch.ones(idx.shape[0], idx.shape[0]).cuda()
    ttl_matrix = torch.matmul(view1, view2.transpose(0, 1))
    topN_matrix = torch.topk(torch.tensor(similarity_idx), int(idx.shape[0] * N))[0][:, -1].unsqueeze(1)
    positive_matrix = torch.tensor(similarity_idx > topN_matrix.numpy()).cuda()
    neg_matrix *= (~positive_matrix)
    positive_matrix = (positive_matrix * 1.0 - torch.diag((positive_matrix * 1.0).diag())) + torch.eye(idx.shape[0]).cuda()
    # 上面是＞不是≥的情况下，如果上面这一行不加上torch.eye()，cl_loss中会产生inf，因为positive中可能某一行全为1(即在这个batch中这个用户没有相似用户)，所以negative这一行全为0，导致分母为0
    neg_matrix = neg_matrix * 1.0 - torch.diag((neg_matrix * 1.0).diag())
    cl_loss = -torch.log((torch.exp(ttl_matrix / temperature) * positive_matrix).sum(dim=1) /
                           (torch.exp(ttl_matrix / temperature) * neg_matrix).sum(dim=1) + 10e-6)
    return torch.mean(cl_loss)

def RankingInfoNCE(view1, view2, origin_view, similarity_matrix, idx, sim_eta, emb_eta, temp, b_cos = True):
    idx = idx.cpu().numpy()

    similarity_idx = similarity_matrix[idx, :][:, idx]
    if b_cos:
        view1, view2, origin_view = F.normalize(view1, dim=1), F.normalize(view2, dim=1), F.normalize(origin_view,dim=1)
    sim_positive_matrix = torch.tensor(similarity_idx > sim_eta).cuda()
    neg_matrix = torch.ones(idx.shape[0], idx.shape[0]).cuda()

    neg_matrix *= (~sim_positive_matrix)
    # sim_positive_matrix = sim_positive_matrix * 1.0 - torch.diag((sim_positive_matrix * 1.0).diag())

    emb_positive_matrix = (torch.matmul(origin_view, origin_view.transpose(0, 1)) > emb_eta)
    # emb_positive_matrix = (torch.matmul(origin_view, view1.transpose(0, 1)) > emb_eta)
    # neg_matrix *= (~emb_positive_matrix)

    # emb_positive_matrix = (emb_positive_matrix * 1.0 - sim_positive_matrix * 1.0) > 0
    # emb_positive_matrix = emb_positive_matrix * 1.0 - torch.diag((emb_positive_matrix * 1.0).diag())

    pos_score = (view1 * view2).sum(dim=-1)
    pos_score = torch.exp(pos_score / temp)
    ttl_matrix = torch.matmul(view1, view2.transpose(0, 1))
    ttl_score = torch.exp(ttl_matrix / temp).sum(dim=1)
    l0 = -torch.log(pos_score / ttl_score + 10e-6)

    # temp2 = temp
    # temp2 = temp + 4.8
    #
    sim_positive_length = torch.count_nonzero(sim_positive_matrix, dim=1)
    # l1 = (torch.log(torch.exp(ttl_matrix / temp) /
    #       (((torch.exp(ttl_matrix / temp) * (neg_matrix * 1.0 + sim_positive_matrix * 1.0 + emb_positive_matrix * 1.0)).sum(dim=1)).reshape(idx.shape[0], 1)) + 10e-6) * sim_positive_matrix).sum(dim=1)
    # l1 *= (-1.0 / (1 + sim_positive_length))

    l1 = (torch.log(torch.exp(ttl_matrix / temp) /
          (((torch.exp(ttl_matrix / temp) * (neg_matrix * 1.0 + sim_positive_matrix * 1.0)).sum(dim=1)).reshape(idx.shape[0], 1)) + 10e-6) * sim_positive_matrix).sum(dim=1)
    l1 *= (-1.0 / (1 + sim_positive_length))

    # emb_positive_length = torch.count_nonzero(emb_positive_matrix, dim=1)
    # l2 = (torch.log(torch.exp(ttl_matrix / temp2) /
    #      (((torch.exp(ttl_matrix / temp2) * (neg_matrix * 1.0 + emb_positive_matrix * 1.0)).sum(dim=1)).reshape(idx.shape[0], 1)) + 10e-6) * emb_positive_matrix).sum(dim=1)
    # l2 *= (-1.0 / (1 + emb_positive_length))
    cl_loss = l0 + l1

    # cl_loss = l0 + l1 + l2

    return torch.mean(cl_loss)




#this version is from recbole
def info_nce(z_i, z_j, temp, batch_size, sim='dot'):
    """
    We do not sample negative examples explicitly.
    Instead, given a positive pair, similar to (Chen et al., 2017), we treat the other 2(N − 1) augmented examples within a minibatch as negative examples.
    """
    def mask_correlated_samples(batch_size):
        N = 2 * batch_size
        mask = torch.ones((N, N), dtype=bool)
        mask = mask.fill_diagonal_(0)
        for i in range(batch_size):
            mask[i, batch_size + i] = 0
            mask[batch_size + i, i] = 0
        return mask

    N = 2 * batch_size

    z = torch.cat((z_i, z_j), dim=0)

    if sim == 'cos':
        sim = nn.functional.cosine_similarity(z.unsqueeze(1), z.unsqueeze(0), dim=2) / temp
    elif sim == 'dot':
        sim = torch.mm(z, z.T) / temp

    sim_i_j = torch.diag(sim, batch_size)
    sim_j_i = torch.diag(sim, -batch_size)

    positive_samples = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)

    mask = mask_correlated_samples(batch_size)

    negative_samples = sim[mask].reshape(N, -1)

    labels = torch.zeros(N).to(positive_samples.device).long()
    logits = torch.cat((positive_samples, negative_samples), dim=1)
    return F.cross_entropy(logits, labels)


def kl_divergence(p_logit, q_logit):
    p = F.softmax(p_logit, dim=-1)
    kl = torch.sum(p * (F.log_softmax(p_logit, dim=-1) - F.log_softmax(q_logit, dim=-1)), 1)
    return torch.mean(kl)

def js_divergence(p_logit, q_logit):
    p = F.softmax(p_logit, dim=-1)
    q = F.softmax(q_logit, dim=-1)
    kl_p = torch.sum(p * (F.log_softmax(p_logit, dim=-1) - F.log_softmax(q_logit, dim=-1)), 1)
    kl_q = torch.sum(q * (F.log_softmax(q_logit, dim=-1) - F.log_softmax(p_logit, dim=-1)), 1)
    return torch.mean(kl_p+kl_q)