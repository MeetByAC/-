import torch
import numpy as np


def calculate_user_dice_similarity(R):
    """
    计算用户之间的 Dice 相似度矩阵。

    参数：
        R (ndarray): 用户-物品交互矩阵 (n_users, n_items)，元素为 0 或 1。

    返回：
        user_dice (ndarray): 用户间的 Dice 相似度矩阵 (n_users, n_users)。
    """
    # 用户-物品交互矩阵 R 的布尔矩阵
    R_bool = (R > 0).astype(int)

    # 用户交互过的物品数量 |I_i| 和 |I_j|
    user_item_count = np.sum(R_bool, axis=1)  # 每个用户交互的物品数量

    # 计算共同交互的物品数量 |I_i ∩ I_j|
    co_occurrence = R_bool @ R_bool.T  # (n_users, n_users) 矩阵，表示共同交互的物品数量

    # 计算用户之间的 Dice 相似度
    user_dice = (2 * co_occurrence) / (user_item_count[:, None] + user_item_count[None, :])

    # 清除对角线（用户自己与自己的相似度无意义）
    np.fill_diagonal(user_dice, 0)

    return user_dice

if __name__ == "__main__":
    R = np.array([
        [1, 0, 1, 0, 0],
        [1, 1, 0, 0, 0],
        [0, 0, 1, 1, 1],
        [0, 1, 0, 1, 0]
    ])
    # 用户交互总数 (按行求和)
    # user_row_sum = np.sum(R, axis=1)
    # item_col_sum = np.sum(R, axis=0)
    #
    # user_intersection = R @ R.T
    # user_union = user_row_sum[:, None] + user_row_sum[None, :] - user_intersection
    # print(user_row_sum)
    # print(user_row_sum[:, None] + user_row_sum[None, :])
    # print("----------------")
    # print(type(user_intersection))
    # print(type(user_union))
    # print(user_union)
    # user_jaccard = np.divide(user_intersection, user_union, out=np.zeros_like(user_intersection, dtype=float), where=user_union != 0)
    # # print(user_jaccard)
    #
    # print("-----------------------------------------------")
    #
    # # 2. 物品 Jaccard 相似度
    # item_intersection = R.T @ R
    # # print(item_intersection)
    # item_union = item_col_sum[:, None] + item_col_sum[None, :] - item_intersection
    # # print(item_union)
    # item_jaccard = np.divide(item_intersection, item_union, out=np.zeros_like(item_intersection, dtype=float), where=item_union != 0)
    # print(item_jaccard)
    # 计算用户间的 Dice 相似度
    user_dice = calculate_user_dice_similarity(R)
    print("用户间的 Dice 相似度矩阵:")
    print(user_dice)