from SELFRec import SELFRec
from util.conf import ModelConf

"""
    LastFM:  user_K = 16   item_K = 6
    SimGCL: lambda: 0.1,   epsilon: 0.2
    user_sim_eta: 0.01,  item_sim_eta: 0.1
    user_sim_eta: 0.04,  item_sim_eta: 0.23
    IW-InfoNCE: user_eta: 0.9, item_eta: 0.9
    S-InfoNCE:  user%N: 0.003,  item%N: 0.003
    Ranking: user_emb_eta: 0.8,  item_emb_eta: 0.8

    SGL:  lambda: 0.05,   droprate: 0.2
    user_sim_eta: 0.01,  item_sim_eta: 0.1
    user_sim_eta: 0.04,  item_sim_eta: 0.23
    IW-InfoNCE: user_eta: 0.8,   item_eta: 0.8
    S-InfoNCE:  user%N: 0.003,   item%N: 0.003
    Ranking: user_emb_eta: 0.8,  item_emb_eta: 0.8
     
    Yelp(这个数据集的实验结果可能要重新跑): 
    SimGCL: lambda: 0.1, epsilon: 0.2
    user_sim_eta: 0.1,  item_sim_eta: 0.1
    IW-InfoNCE: user_eta: 0.8, item_eta: 0.8
    S-InfoNCE:  user%N: 0.005,  item%N: 0.005
    Ranking:  user_sim_eta:0.05, item_sim_eta:0.08, user_emb_eta: 0.8, item_emb_eta: 0.8
    
    SGL:  lambda: 0.05,   droprate: 0.2
    user_sim_eta: 0.1,  item_sim_eta: 0.1
    user_sim_eta: 0.08,  item_sim_eta: 0.08
    IW-InfoNCE: user_eta: 0.9, item_eta: 0.9
    S-InfoNCE:  user%N: 0.005,  item%N: 0.005
    Ranking:  user_sim_eta:0.05, item_sim_eta:0.08, user_emb_eta: 0.8, item_emb_eta: 0.8
    
    Douban-Book: 
    SimGCL: lambda: 0.2, epsilon: 0.2
    IW-InfoNCE: user_eta: 0.8, item_eta: 0.8
    S-InfoNCE:  user%N: 0.003,  item%N: 0.003
    Ranking:  user_emb_eta: 0.8, item_emb_eta: 0.8,  user_sim_eta: 0.05, item_sim_eta: 0.2
    
    SGL: lambda: 0.1, droprate: 0.2
    IW-InfoNCE: user_eta: 0.6, item_eta: 0.6
    S-InfoNCE:  user%N: 0.005,  item%N: 0.005
    Ranking:  user_emb_eta: 0.7, item_emb_eta: 0.7,  user_sim_eta: 0.05, item_sim_eta: 0.2
    -------------------------
    
    ml-1M: 
    SimGCL: lambda: 0.1, epsilon: 0.1
    lambda: 0.05, epsilon: 0.05
    user_sim_eta 0.05, item_sim_eta 0.6
    SimGCL=-n_layer 2 -lambda 0.1 -eps 0.2 -user_emb_eta 0.8 -item_emb_eta 0.8 -user_sim_eta 0.05 -item_sim_eta 0.6
    SGL: lambda: 0.01,   droprate: 0.1
    user_sim_eta: xxx,  item_sim_eta: xxx
"""

import os
import torch
import numpy as np
import random
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

def set_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)  # if you are using multi-GPU.
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.

    # torch.set_deterministic(True)
    # # torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.enabled = False
    # torch.backends.cudnn.benchmark = False
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
    os.environ['PYTHONHASHSEED'] = str(seed)

if __name__ == '__main__':
    # Register your model here
    graph_baselines = ['LightGCN','DirectAU','MF']
    ssl_graph_models = ['SGL', 'SimGCL', 'SEPT', 'MHCN', 'BUIR', 'SelfCF', 'SSL4Rec', 'XSimGCL', 'NCL','MixGCF']
    sequential_baselines= ['SASRec']
    ssl_sequential_models = ['CL4SRec','DuoRec','BERT4Rec']

    set_seed(2020)

    print('=' * 80)
    print('   SELFRec: A library for self-supervised recommendation.   ')
    print('=' * 80)

    print('Graph-Based Baseline Models:')
    print('   '.join(graph_baselines))
    print('-' * 100)
    print('Self-Supervised  Graph-Based Models:')
    print('   '.join(ssl_graph_models))
    print('=' * 80)
    print('Sequential Baseline Models:')
    print('   '.join(sequential_baselines))
    print('-' * 100)
    print('Self-Supervised Sequential Models:')
    print('   '.join(ssl_sequential_models))
    print('=' * 80)
    model = input('Please enter the model you want to run:')
    import time

    s = time.time()
    if model in graph_baselines or model in ssl_graph_models or model in sequential_baselines or model in ssl_sequential_models:
        conf = ModelConf('./conf/' + model + '.conf')
    else:
        print('Wrong model name!')
        exit(-1)
    rec = SELFRec(conf)
    rec.execute()
    e = time.time()
    print("Running time: %f s" % (e - s))

    # Douban_sim_user_eta = [0.0, 0.01, 0.05, 0.08, 0.1, 0.2, 0.5, 0.8, 1.0]
    # item_eta = 0.2
    # for user_eta in Douban_sim_user_eta:
    #         if model in graph_baselines or model in ssl_graph_models or model in sequential_baselines or model in ssl_sequential_models or model:
    #             with open('./conf/' + model + '.conf') as f:
    #                 content_list = f.readlines()
    #                 content_list[10] = model + '=-n_layer 2' + ' -lambda 0.2' + ' -eps 0.2' + \
    #                 ' -user_emb_eta 0.8 -item_emb_eta 0.8 -user_sim_eta ' + str(user_eta) + ' -item_sim_eta 0.2' + '\n'
    #                 f = open('./conf/' + model + '.conf', 'w')
    #                 f.writelines(content_list)
    #                 f.close()
    #                 conf = ModelConf('./conf/' + model + '.conf')  # 初始化配置
    #         else:
    #             print('Wrong model name!')
    #             exit(-1)
    #         rec = SELFRec(conf)
    #         rec.execute()

    # user_etas = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.1,
    #                 0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2,
    #                 0.21, 0.22, 0.23, 0.24, 0.25, 0.26, 0.27, 0.28, 0.29, 0.3,
    #                 0.31, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.38, 0.39, 0.4]

    # item_etas = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.1,
    #                 0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2,
    #                 0.21, 0.22, 0.23, 0.24, 0.25, 0.26, 0.27, 0.28, 0.29, 0.3,
    #                 0.31, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.38, 0.39, 0.4]
    #
    # lambda_set = [0.7]
    # eplison_set = [0.2, 0.3, 0.4, 0.5]
    # for Lambda in lambda_set:
    #     for Eplison in eplison_set:
    #         if model in graph_baselines or model in ssl_graph_models or model in sequential_baselines or model in ssl_sequential_models or model:
    #             with open('./conf/' + model + '.conf') as f:
    #                 content_list = f.readlines()
    #                 content_list[10] = model + '=-n_layer 2' + ' -lambda ' + str(Lambda) + ' -eps ' + str(Eplison) + \
    #                 ' -user_emb_eta 1.7 -item_emb_eta 1.7 -user_sim_eta 0.01 -item_sim_eta 0.1 -user_jaccard_eta 0.01 -item_jaccard_eta 0.1' + '\n'
    #                 f = open('./conf/' + model + '.conf', 'w')
    #                 f.writelines(content_list)
    #                 f.close()
    #                 conf = ModelConf('./conf/' + model + '.conf')  # 初始化配置
    #         else:
    #             print('Wrong model name!')
    #             exit(-1)
    #         rec = SELFRec(conf)
    #         rec.execute()