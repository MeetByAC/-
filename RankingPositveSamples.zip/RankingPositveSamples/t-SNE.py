import torch
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

# 数据集和方法列表
datasets = ["lastfm", "Yelp", "Douban"]  # 3个数据集
# datasets = ["lastfm", "Yelp"]  # 2个数据集
methods = ["SGL", "SimGCL", "SimGCL_SInfoNCE", "SimGCL_CLIW", "SimGCL_PRCL"]  # 5种方法
nums = [(1888 , 15449) , (19539 , 21302), (12638, 22222)]
num_samples = 1600  # 每类最多采样的数量（用户/物品）

for i, dataset in enumerate(datasets):  # 遍历数据集，每个数据集生成一张图
    fig, axes = plt.subplots(1, len(methods), figsize=(15, 3))  # 每张图 1 行 5 列

    # 1. 加载某个数据集的嵌入数据（所有方法共享同一索引）
    file_path = f"{dataset}_{methods[0]}_emb.pth"  # 先读取第一个方法的文件
    embeddings = torch.load(file_path).cpu().numpy()

    # 2. 拆分用户和物品嵌入
    num_users= nums[i][0]
    user_emb, item_emb = embeddings[:num_users], embeddings[num_users:]

    # 3. **生成固定的随机索引**（所有方法共享）
    np.random.seed(42)  # 设定种子，保证结果一致
    user_idx = np.random.choice(user_emb.shape[0], min(num_samples, user_emb.shape[0]), replace=False)
    item_idx = np.random.choice(item_emb.shape[0], min(num_samples, item_emb.shape[0]), replace=False)

    for j, method in enumerate(methods):  # 遍历方法
        # 4. 加载当前方法的嵌入数据
        file_path = f"{dataset}_{method}_emb.pth"
        embeddings = torch.load(file_path).cpu().numpy()

        # 5. 拆分用户和物品嵌入
        user_emb, item_emb = embeddings[:num_users], embeddings[num_users:]

        # 6. 采样相同索引的用户和物品嵌入
        sampled_user_emb, sampled_item_emb = user_emb[user_idx], item_emb[item_idx]

        # 7. 计算 t-SNE
        tsne = TSNE(n_components=2, random_state=42)
        user_emb_2d, item_emb_2d = tsne.fit_transform(sampled_user_emb), tsne.fit_transform(sampled_item_emb)

        # 8. 绘制散点图
        ax = axes[j]
        ax.scatter(user_emb_2d[:, 0], user_emb_2d[:, 1], alpha=0.6, c='cornflowerblue', label='Users', s=5)
        # ax.scatter(item_emb_2d[:, 0], item_emb_2d[:, 1], alpha=0.6, c='red', label='Items', s=5)
        ax.set_title(f"{method}")
        # ax.legend()

    # 9. 保存当前数据集的图为 SVG
    # plt.savefig(f"{dataset}.svg", format='svg', bbox_inches='tight')
    plt.tight_layout()
    plt.show()  # 显示当前数据集的图

# for i, dataset in enumerate(datasets):  # 遍历数据集，每个数据集生成一张图
#     fig, axes = plt.subplots(1, len(methods), figsize=(15, 3))  # 每张图 1 行 5 列
#
#     for j, method in enumerate(methods):  # 遍历方法
#         # 1. 加载嵌入数据
#         file_path = f"{dataset}_{method}_emb.pth"  # 假设文件命名为 "dataset1_method1.pth"
#         embeddings = torch.load(file_path).cpu().numpy()
#
#         # 2. 拆分用户和物品嵌入
#         num_users= nums[i][0]
#         user_emb, item_emb = embeddings[:num_users], embeddings[num_users:]
#
#         # 3. 随机采样用户和物品
#         user_idx = np.random.choice(user_emb.shape[0], min(num_samples, user_emb.shape[0]), replace=False)
#         item_idx = np.random.choice(item_emb.shape[0], min(num_samples, item_emb.shape[0]), replace=False)
#         sampled_user_emb, sampled_item_emb = user_emb[user_idx], item_emb[item_idx]
#
#         # 4. 计算 t-SNE
#         tsne = TSNE(n_components=2, random_state=42)
#         user_emb_2d, item_emb_2d = tsne.fit_transform(sampled_user_emb), tsne.fit_transform(sampled_item_emb)
#         # tsne = TSNE(n_components=2, random_state=42)
#         # user_emb_2d, item_emb_2d = tsne.fit_transform(user_emb), tsne.fit_transform(item_emb)
#
#         # 5. 绘制散点图
#         ax = axes[j]
#         ax.scatter(user_emb_2d[:, 0], user_emb_2d[:, 1], alpha=0.6, c='blue', label='User')
#         ax.scatter(item_emb_2d[:, 0], item_emb_2d[:, 1], alpha=0.6, c='red', label='Item')
#         ax.set_title(f"{method}")
#         ax.legend()
#
#     # plt.savefig(f"{dataset}.pth", format='svg', bbox_inches='tight')
#     plt.tight_layout()
#     plt.show()  # 显示当前数据集的图