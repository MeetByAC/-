from matplotlib.lines import Line2D

#
# # 创建2行3列的子图
# fig, axs = plt.subplots(2, 3, figsize=(10, 8))
#
# axs[0,0].scatter(lastfm_sim_user_eta, lastfm_SimGCL_Recall1, color='cornflowerblue', label='Recall1', marker='o')
# axs[0,0].plot(lastfm_sim_user_eta, lastfm_SimGCL_Recall1, color='cornflowerblue', linestyle='-', linewidth=2)
# axs[0,0].scatter(lastfm_sim_user_eta, lastfm_SimGCL_NDCG1, color='darkorange', label='NDCG1', marker='s')
# axs[0,0].plot(lastfm_sim_user_eta, lastfm_SimGCL_NDCG1, color='darkorange', linestyle='-', linewidth=2)
# axs[0,0].grid(True, color='gray', linestyle=':', linewidth=1)
# legend_elements = [
#     Line2D([0], [0], color='cornflowerblue', lw=2, marker='o', markersize=8, label='Recall'),
#     Line2D([0], [0], color='darkorange', lw=2, marker='s', markersize=8, label='NDCG')
# ]
# # 添加自定义图例
# axs[0,0].legend(handles=legend_elements, loc='lower right')
# axs[0,0].set_xlabel(r'$\alpha_{user}$')
#
# axs[0,1].scatter(Yelp_sim_user_eta, Yelp_SimGCL_Recall1, color='cornflowerblue', label='Recall2', marker='o')
# axs[0,1].plot(Yelp_sim_user_eta, Yelp_SimGCL_Recall1, color='cornflowerblue', linestyle='-', linewidth=2)
# axs[0,1].scatter(Yelp_sim_user_eta, Yelp_SimGCL_NDCG1, color='darkorange', label='NDCG2', marker='s')
# axs[0,1].plot(Yelp_sim_user_eta, Yelp_SimGCL_NDCG1, color='darkorange', linestyle='-', linewidth=2)
# axs[0,1].grid(True, color='gray', linestyle=':', linewidth=1)
# legend_elements = [
#     Line2D([0], [0], color='cornflowerblue', lw=2, marker='o', markersize=8, label='Recall'),
#     Line2D([0], [0], color='darkorange', lw=2, marker='s', markersize=8, label='NDCG')
# ]
# # 添加自定义图例
# axs[0,1].legend(handles=legend_elements, loc='lower right')
# axs[0,1].set_xlabel(r'$\alpha_{user}$')
#
# axs[0,2].scatter(Douban_sim_user_eta, Douban_SimGCL_Recall1, color='cornflowerblue', label='Recall2', marker='o')
# axs[0,2].plot(Douban_sim_user_eta, Douban_SimGCL_Recall1, color='cornflowerblue', linestyle='-', linewidth=2)
# axs[0,2].scatter(Douban_sim_user_eta, Douban_SimGCL_NDCG1, color='darkorange', label='NDCG2', marker='s')
# axs[0,2].plot(Douban_sim_user_eta, Douban_SimGCL_NDCG1, color='darkorange', linestyle='-', linewidth=2)
# axs[0,2].grid(True, color='gray', linestyle=':', linewidth=1)
# legend_elements = [
#     Line2D([0], [0], color='cornflowerblue', lw=2, marker='o', markersize=8, label='Recall'),
#     Line2D([0], [0], color='darkorange', lw=2, marker='s', markersize=8, label='NDCG')
# ]
# # 添加自定义图例
# axs[0,1].legend(handles=legend_elements, loc='lower right')
# axs[0,1].set_xlabel(r'$\alpha_{user}$')
#
#
# axs[1,0].scatter(lastfm_sim_item_eta, lastfm_SimGCL_Recall2, color='cornflowerblue', label='Recall3', marker='o')
# axs[1,0].plot(lastfm_sim_item_eta, lastfm_SimGCL_Recall2, color='cornflowerblue', linestyle='-', linewidth=2)
# axs[1,0].scatter(lastfm_sim_item_eta, lastfm_SimGCL_NDCG2, color='darkorange', label='NDCG3', marker='s')
# axs[1,0].plot(lastfm_sim_item_eta, lastfm_SimGCL_NDCG2, color='darkorange', linestyle='-', linewidth=2)
# axs[1,0].grid(True, color='gray', linestyle=':', linewidth=1)
# legend_elements = [
#     Line2D([0], [0], color='cornflowerblue', lw=2, marker='o', markersize=8, label='Recall'),
#     Line2D([0], [0], color='darkorange', lw=2, marker='s', markersize=8, label='NDCG')
# ]
# # 添加自定义图例
# axs[1,0].legend(handles=legend_elements, loc='lower right')
# axs[1,0].set_xlabel(r'$\alpha_{user}$')
#
#
# axs[1,1].scatter(Yelp_sim_item_eta, Yelp_SimGCL_Recall2, color='cornflowerblue', label='Recall4', marker='o')
# axs[1,1].plot(Yelp_sim_item_eta, Yelp_SimGCL_Recall2, color='cornflowerblue', linestyle='-', linewidth=2)
# axs[1,1].scatter(Yelp_sim_item_eta, Yelp_SimGCL_NDCG2, color='darkorange', label='NDCG4', marker='s')
# axs[1,1].plot(Yelp_sim_item_eta, Yelp_SimGCL_NDCG2, color='darkorange', linestyle='-', linewidth=2)
# axs[1,1].grid(True, color='gray', linestyle=':', linewidth=1)
# legend_elements = [
#     Line2D([0], [0], color='cornflowerblue', lw=2, marker='o', markersize=8, label='Recall'),
#     Line2D([0], [0], color='darkorange', lw=2, marker='s', markersize=8, label='NDCG')
# ]
# # 添加自定义图例
# axs[1,1].legend(handles=legend_elements, loc='lower right')
# axs[1,1].set_xlabel(r'$\alpha_{item}$')
#
#
# # 保存图形为 SVG 格式
# plt.savefig("hyperExperiment.svg", format='svg')
#
# # 显示图形
# plt.show()
#


# f, ([ax1, ax2, ax3, ax4, ax5, ax6]) = plt.subplots(2, 3, figsize=(8,3.5), sharex=False)

import numpy as np
import matplotlib
import matplotlib.pyplot as plt

"""
    python matplotlib画图产生的Type 3 fonts字体不兼容
    使用Type 42字体来生成PostScript和PDF文件

    当希望横坐标刻度看起来是等距的，而且每个数据点对应于刻度时，
    可以使用实际数据点的索引作为x轴刻度的位置，然后将实际横坐标值用作刻度标签
"""
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42

# x1 = np.array([0, 0.01, 0.05, 0.1, 0.2, 0.5, 0.8, 1.0])
# x2 = np.array([0, 0.01, 0.05, 0.1, 0.2, 0.5, 0.8, 1.0])
# y1 = np.array([13, 14, 15, 16, 17, 18, 19])
#
#
# Recall_1 = np.array([17.979, 18.079, 18.462, 18.101, 17.76, 17.746, 17.786, 17.74])
# NDCG_1 = np.array([15.849, 15.938, 16.586, 16.53, 15.854, 15.727, 15.753, 15.69])
#
# Recall_2 = np.array([17.664, 17.711, 17.171, 17.377, 18.48, 18.056, 17.86, 17.74])
# NDCG_2 = np.array([15.706, 15.751, 14.936, 15.047, 16.45, 16.01, 15.757, 15.69])


# 数据点, 一个值取最优去调整另一个值
lastfm_sim_user_eta = [0.0,    0.01,   0.05,   0.08,   0.1,    0.2,   0.3,   0.5]
lastfm_sim_item_eta = [0.0,    0.01,   0.05,   0.08,   0.1,    0.2,   0.3,   0.5]

lastfm_SGL_Recall1  = [0.3268, 0.3309, 0.3253, 0.3235, 0.3212, 0.3213, 0.3286 , 0.3]
lastfm_SGL_NDCG1    = [0.3116, 0.3149, 0.3108, 0.3010, 0.3077, 0.3085, 0.3123 , 0.3]

lastfm_SGL_Recall2  = []
lastfm_SGL_NDCG2    = []

lastfm_SimGCL_Recall1  = [0.3281,   0.3300,  0.3249,   0.3231,  0.3205,   0.3185,  0.3227,  0.3258]
lastfm_SimGCL_NDCG1    = [0.3144,   0.3150,  0.3124,   0.3107,  0.3072,   0.3054,  0.3082,  0.3110]

# 0.3  Recall:0.32646  |  NDCG:0.31245
# 0.05 Recall:0.32711  |  NDCG:0.31211
# 0.01 Recall:0.3249  |  NDCG:0.31101
lastfm_SimGCL_Recall2  = [0.3263,   0.3269,  0.3277,   0.3282,  0.3300,   0.3276,  0.3265,  0.3240]
lastfm_SimGCL_NDCG2    = [0.3110,   0.3129,  0.3138,   0.3133,  0.3150,   0.3138,  0.3125,  0.3104]


# ---------------------------------------------------------------------------------

Yelp_sim_user_eta = [0.0,   0.01,  0.05,  0.08,  0.1,   0.2,  0.3,  0.5]
Yelp_sim_item_eta = [0.0,   0.01,  0.05,  0.08,  0.1,   0.2,  0.3,  0.5]

# Yelp_SGL_Recall1  = [0.3, 0.3, 0.3, 0.1, 0.3, 0.3, 0.3  , 0.3]
# Yelp_SGL_NDCG1    = [0.3, 0.3, 0.4, 0.1, 0.3, 0.5, 0.3 , 0.3]
#
# Yelp_SGL_Recall2  = []
# Yelp_SGL_NDCG2    = []

Yelp_SimGCL_Recall1  = [0.1329,  0.1335,  0.1343,   0.1322,  0.1327,  0.,  0., 0.1316]
Yelp_SimGCL_NDCG1    = [0.0857,  0.0858,  0.0868,   0.0860,  0.08,   0.,  0.,  0.0850]

Yelp_SimGCL_Recall2  = [0.0,   0.0,  0.0,   0.1343,  0.,   0.,  0.,   0.]
Yelp_SimGCL_NDCG2    = [0.0,   0.0,  0.0,   0.0868,  0.,   0.,  0.,   0.]

# ---------------------------------------------------------------------------------

Douban_sim_user_eta = [0.0,    0.01,   0.05,   0.08,  0.1,   0.2,  0.3,   0.5]
Douban_sim_item_eta = [0.0,    0.01,   0.05,   0.08,  0.1,   0.2,  0.3,   0.5]

Douban_SGL_Recall1  = [0.1861, 0.1871, 0.3, 0.3, 0.3, 0.3, 0.3  , 0.3]
Douban_SGL_NDCG1    = [0.1671, 0.1678, 0.3, 0.3, 0.3, 0.3, 0.3  , 0.3]

Douban_SGL_Recall2  = []
Douban_SGL_NDCG2    = []

Douban_SimGCL_Recall1  = [0.1841, 0.1863, 0.1887, 0.1854, 0.1843,  0.1823, 0.1833, 0.1818]
Douban_SimGCL_NDCG1    = [0.1643, 0.1657, 0.1697, 0.1683, 0.1678,  0.1640, 0.1641, 0.1634]
# 0.3:  Recall:0.18283  |  NDCG:0.16387 |  Recall:0.18329  |  NDCG:0.16409   Recall:0.18202  |  NDCG:0.16286

Douban_SimGCL_Recall2  = [0.1815, 0.1824, 0.1791, 0.1783, 0.1802, 0.1887, 0.1855, 0.1824]
Douban_SimGCL_NDCG2    = [0.1647, 0.1654, 0.1606, 0.1581, 0.1593, 0.1697, 0.1686, 0.1658]
# 0.0: Recall:0.18308  |  NDCG:0.16508
# 0.01: 0.1798  0.1635

# 创建图形和坐标轴对象, figsize:指定figure的宽和高，单位为英寸；
# f, ([ax1, ax2, ax3, ax4], [ax5, ax6, ax7, ax8]) = plt.subplots(2, 4, figsize=(26,24), sharex=False)
f, ([ax1, ax2], [ax3, ax4]) = plt.subplots(2, 2, figsize=(16,14), sharex=False)

lastfm_yaxis = np.array([0.305, 0.310, 0.315, 0.320, 0.325, 0.330, 0.335])
Yelp_yaxis = np.array([0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2])
Douban_yaxis = np.array([0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2])

def percent_formatter(x):
    return f"{x:.1f}%"

ax1.plot(range(len(lastfm_sim_user_eta)), lastfm_SimGCL_Recall1, marker="o", color="cornflowerblue", label="Recall", linestyle='-')
ax1.plot(range(len(lastfm_sim_user_eta)), lastfm_SimGCL_NDCG1, marker="s", color="darkorange", label="NDCG", linestyle='-')
# 设置横坐标刻度和标签，使用实际横坐标值作为标签
ax1.set_xticks(range(len(lastfm_sim_user_eta)))
ax1.set_xticklabels([str(x) for x in lastfm_sim_user_eta], fontsize=18)
ax1.tick_params(axis='y', labelsize=18)
# ax1.set_yticks(lastfm_yaxis)
# 设置y轴刻度标朝向内部
# ax1.tick_params(axis='y', direction='in')
# ax1.set_title('SimGCL+PRCL')
ax1.set_xlabel('$\\alpha_{user}$', fontsize=20)
ax1.legend(loc='best', fontsize=18)
ax1.grid(True,linestyle='dotted')

ax2.plot(range(len(lastfm_sim_item_eta)), lastfm_SimGCL_Recall2, marker="o",color="cornflowerblue", label="Recall", linestyle='-')
ax2.plot(range(len(lastfm_sim_item_eta)), lastfm_SimGCL_NDCG2, marker="s", color="darkorange", label="NDCG", linestyle='-')
ax2.set_xticks(range(len(lastfm_sim_item_eta)))
ax2.set_xticklabels([str(x) for x in lastfm_sim_item_eta], fontsize=18)
fig2_yaxis = [0.310, 0.315, 0.320, 0.325, 0.330, 0.335, 0.340]
ax2.set_yticks(fig2_yaxis)
ax2.tick_params(axis='y', labelsize=18)
# ax2.set_yticks(lastfm_yaxis)
# ax2.set_title('SimGCL+PRCL')
from matplotlib.ticker import FormatStrFormatter
ax2.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
ax2.set_xlabel('$\\alpha_{item}$', fontsize=20)
ax2.legend(loc='upper right', fontsize=18)
# ax2.legend(loc='best')
ax2.grid(True,linestyle='dotted')


ax3.plot(range(len(Douban_sim_user_eta)), Douban_SimGCL_Recall1, marker="o", color="cornflowerblue", label="Recall", linestyle='-')
ax3.plot(range(len(Douban_sim_user_eta)), Douban_SimGCL_NDCG1, marker="s", color="darkorange", label="NDCG", linestyle='-')
# 设置横坐标刻度和标签，使用实际横坐标值作为标签
ax3.set_xticks(range(len(Douban_sim_user_eta)))
ax3.set_xticklabels([str(x) for x in Douban_sim_user_eta], fontsize=18)
ax3.tick_params(axis='y', labelsize=18)
# ax7.set_yticks(Douban_yaxis)
# 设置y轴刻度标朝向内部
# ax7.tick_params(axis='y', direction='in')
# ax3.set_title('SimGCL+PRCL')
ax3.set_xlabel('$\\alpha_{user}$', fontsize=20)
ax3.legend(loc='best', fontsize=18)
ax3.grid(True,linestyle='dotted')


ax4.plot(range(len(Douban_sim_item_eta)), Douban_SimGCL_Recall2, marker="o",color="cornflowerblue", label="Recall", linestyle='-')
ax4.plot(range(len(Douban_sim_item_eta)), Douban_SimGCL_NDCG2, marker="s", color="darkorange", label="NDCG", linestyle='-')
ax4.set_xticks(range(len(Douban_sim_item_eta)))
ax4.set_xticklabels([str(x) for x in Douban_sim_item_eta], fontsize=18)
ax4.tick_params(axis='y', labelsize=18)
# ax6.set_yticks(Douban_yaxis)
# ax4.set_title('SimGCL+PRCL')
ax4.set_xlabel('$\\alpha_{item}$', fontsize=20)
ax4.legend(loc='best', fontsize=18)
ax4.grid(True,linestyle='dotted')


"""
    subplots_adjust()方法来调整图表与画布之间的间距，以及图表与图表之间的间距
    避免图片内容显示不全
    图与图之间的间距调整wspace=0.25
"""
# plt.savefig('output.pdf', format='pdf', bbox_inches='tight')
plt.savefig("hyperExperiment.svg", format='svg', bbox_inches='tight')
plt.subplots_adjust(wspace=0.2, hspace=0.15, bottom=0.1)
plt.show()

